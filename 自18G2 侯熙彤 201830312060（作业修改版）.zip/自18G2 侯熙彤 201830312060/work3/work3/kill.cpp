#include<iostream>                  
#include"hero.h"
using namespace std;

int main()
{
	Hero A(200, 1);
	Hero B(300, 2);
	Hero C(240, 3);
	Hero D(350, 4);
	Hero E(400, 5);
	A.damage();
	cout << "����A�ѱ���ɱ" << endl;
	B.damage();
	cout << "˫ɱ" << endl;
	C.damage();
	cout << "��ɱ" << endl;
	D.damage();
	cout << "��ɱ" << endl;
	E.damage();
	cout << "��ɱ" << endl;
	return 0;
}
