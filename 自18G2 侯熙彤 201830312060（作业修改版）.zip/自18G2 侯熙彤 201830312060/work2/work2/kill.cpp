#include<iostream>                  
#include"hero.h"
using namespace std;

int main()
{
	Hero A(200);
	Hero B(300);
	Hero C(240);
	Hero D(350);
	Hero E(400);
	A.damage();
	cout << "����A�ѱ���ɱ" << endl;
	B.damage();
	cout << "˫ɱ" << endl;
	C.damage();
	cout << "��ɱ" << endl;
	D.damage();
	cout << "��ɱ" << endl;
	E.damage();
	cout << "��ɱ" << endl;
	return 0;
}
