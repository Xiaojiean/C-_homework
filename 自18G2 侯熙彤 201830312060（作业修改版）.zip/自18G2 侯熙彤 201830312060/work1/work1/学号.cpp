#include<iostream>
using namespace std;
int main()
{
	int number;
	cout << "����ͮͬѧ��ѧ�ţ�" << endl;
	cin >> number;
	cout << "**** ****\n*    *  *\n**** *  *\n*  * *  *\n**** ****\n";
	return 0;
}