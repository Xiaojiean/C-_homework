#include<iostream>
using namespace std;

class Hero
{
public:
	Hero(int x1);
	void attack();
	void damage();
	int s1,s2;
private:
	int skill1;
	int skill2;
	int HP;
	static int count;
};
inline void Hero::attack()
{
	for (; HP > 200;)
	{
		HP = HP - 20;
		cout << "���� -20" << endl;
	}
	cout << "�����ѵ�Ѫ���ͷż���" << endl;
}