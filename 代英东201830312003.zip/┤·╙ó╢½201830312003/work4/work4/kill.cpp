#include<iostream>                  
#include"hero.h"
using namespace std;

int main()
{
	Hero A(200);
	Hero B(300);
	A.damage();
	cout << "����A�ѱ���ɱ" << endl;
	B.damage();
	cout << "˫ɱ" << endl;
	return 0;
}
