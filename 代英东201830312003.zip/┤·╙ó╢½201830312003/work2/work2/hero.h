#include< iostream>
using namespace std;
void Shixin();
void Linghunchongji();
void Ouxiangmeili();
void Nvwangchongbai();