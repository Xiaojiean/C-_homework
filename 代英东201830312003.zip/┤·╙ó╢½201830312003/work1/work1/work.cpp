#include<iostream>
using namespace std;
int main()
{
	cout << "��18G2��Ӣ����ѧ�ţ�" << endl;
	int x;
	cin >> x;	
	cout << "   ******   ******\n";
	cout << "   *    *        *\n";
	cout << "   *    *   ******\n";
	cout << "   *    *        *\n";
	cout << "   ******   ******\n";
	return 0;
}