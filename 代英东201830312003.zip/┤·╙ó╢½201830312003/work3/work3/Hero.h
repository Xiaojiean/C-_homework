#include<iostream>
using namespace std;

class Hero
{
public:
	Hero(int x1, int x2);
	~Hero();
	void attack();
	void damage();
	int i;
private:
	int skill1;
	int skill2;
	int HP;
};
inline void Hero::attack()
{
	for (; HP > 200;)
	{
		HP = HP - 20;
		cout << "���� -20" << endl;
	}
	cout << "�����ѵ�Ѫ���ͷż���" << endl;
}