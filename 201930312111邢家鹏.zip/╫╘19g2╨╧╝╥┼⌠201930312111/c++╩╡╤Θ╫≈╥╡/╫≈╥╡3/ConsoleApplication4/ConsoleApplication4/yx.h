#include <iostream>

using namespace std;

class yx
{
public:
        yx();
		yx( int xl,int mf);
		void showd();
		void jiaxue();
		void at();
		~yx();
		int d1;
	    int d2;
private:
	

};
