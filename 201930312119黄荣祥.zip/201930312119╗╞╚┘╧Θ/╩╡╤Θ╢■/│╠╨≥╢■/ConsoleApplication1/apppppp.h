#include <iostream> 

using namespace std; 
void shengguangshouhu(int attacks);
void shiyuezhidun(int skill1);
void huixuandaji(int skill2);
void shengjiancaijue(int  skill3 );