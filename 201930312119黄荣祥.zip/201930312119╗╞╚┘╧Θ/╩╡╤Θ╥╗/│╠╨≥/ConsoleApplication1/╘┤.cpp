#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int xuehao;
	cout<<"Please input your xuehao:"<<endl;
	cin>>xuehao;
	cout<<"    *   "<<"    "<<"* * * * *"<<endl;
	cout<<"    *   "<<"    "<<"*       *"<<endl;
	cout<<"    *   "<<"    "<<"* * * * *"<<endl;
	cout<<"    *   "<<"    "<<"        *"<<endl;
	cout<<"    *   "<<"    "<<"* * * * *"<<endl;
	getch();
	return 0;
}