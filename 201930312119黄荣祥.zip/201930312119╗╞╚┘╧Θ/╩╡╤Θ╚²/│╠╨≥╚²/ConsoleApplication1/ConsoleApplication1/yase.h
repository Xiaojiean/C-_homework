#include <iostream>

using namespace std;

class yase
{
public:
        yase();
		yase( int Ѫ��,int ����,int ����);
		void shuchu();
		void shangha();
		void lianjin();
		void at();
		~yase();
		int d1;
	    int d2;
        int d3;
};
