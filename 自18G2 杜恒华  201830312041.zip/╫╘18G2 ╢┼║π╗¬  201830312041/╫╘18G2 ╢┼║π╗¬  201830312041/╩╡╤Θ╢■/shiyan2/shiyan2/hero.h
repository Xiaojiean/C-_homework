﻿#include<iostream>
using namespace std;

class Hero
{
public:
	Hero();
	void attack();
};
inline void Hero::attack()
{
	cout << "平A，平A，血线低" << endl;
}