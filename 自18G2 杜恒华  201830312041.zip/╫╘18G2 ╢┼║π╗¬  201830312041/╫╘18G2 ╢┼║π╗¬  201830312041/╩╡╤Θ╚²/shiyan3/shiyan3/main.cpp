#include <iostream>
#include"hero.h"
using namespace std;
int main()
{
	Hero libai;
	cout << "libai" << endl;
	libai.showskill();

	Hero sunwukong(10, 10, 10);
	cout << "sunwukong" << endl;
	sunwukong.showskill();

	Hero liubei(sunwukong);
	cout << "liubei" << endl;
   liubei.showskill();

	libai = sunwukong;
	cout << "libai" << endl;
	libai.showskill();

	return 0;
}