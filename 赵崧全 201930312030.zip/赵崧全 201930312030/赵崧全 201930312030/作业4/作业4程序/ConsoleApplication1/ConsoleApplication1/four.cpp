#include <iostream>
#include "four.h"
using namespace std; 
LOL::LOL( int HP,int AD)
{	
   FFF=HP;
   QQQ=AD;
}
void LOL ::showd()
{
cout<<"Ѫ��:";cout<<FFF<<endl;
cout<<"����:";cout<<QQQ<<endl;
}
void LOL::FLZT1()
{
CJ=CJ-1;
FFF= FFF-100;
}
void LOL::FLZT2()
{
FFF= FFF-50;
}
LOL::~LOL ()
{
cout<<"Ұ������\n"<<endl ;
};
