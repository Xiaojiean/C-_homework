#include <iostream>
using namespace std;

class LOL
{
public:
        LOL();
		LOL( int HP,int AD);
		void showd();
		void FLZT1();
		void FLZT2();
		~LOL();
		int FFF;
	    int QQQ;
		int CJ;
private:
	

};