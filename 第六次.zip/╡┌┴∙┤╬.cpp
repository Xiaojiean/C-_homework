#include <iostream>
#include <string>
using namespace std;
class MyArray {
public:
    MyArray(int length);
    ~MyArray();
    void Input();
    void Display(string);
protected:
    int alist[20];
    int length;
};

class SortArray :public MyArray {
public:
    SortArray(int a);
    ~SortArray();
    void sort();

};

void SortArray::sort()
{
    int i, x, j;
    for (j = 0; j < length; j++)
    {
        for (i = j + 1; i < length; i++)
        {
            if (alist[j] > alist[i])
            {
                x = alist[i];
                alist[i] = alist[j];
                alist[j] = x;
            }
        }

    }

}

MyArray::MyArray(int leng)
{
    if (leng <= 0)
    {
        cout << "error length";
        exit(1);
    }
    length = leng;
    cout << "MyArray������Ѵ���!" << endl;
}

SortArray::SortArray(int a) :MyArray(a)
{
    cout << "SortArray������Ѵ���!" << endl;
}
SortArray::~SortArray()
{
    cout << "SortArray������ѳ���!" << endl;
}


MyArray::~MyArray()
{
    cout << "MyArray������ѳ���!" << endl;
}

void MyArray::Display(string str)
{
    int i;
    int* p = alist;
    cout << str << length << "������: ";
    for (i = 0; i < length; i++, p++)
        cout << *p << " ";
    cout << endl;
}
void MyArray::Input()
{
    cout << "��Ӽ�������" << length << "������:";
    int i;
    int* p = alist;
    for (i = 0; i < length; i++, p++)
        cin >> *p;
}
int main()
{
    SortArray a(5);
    a.Input();
    a.Display("��ʾ������ǰ��");
    a.sort();
    a.Display("��ʾ�����Ժ��");
    return 0;
}