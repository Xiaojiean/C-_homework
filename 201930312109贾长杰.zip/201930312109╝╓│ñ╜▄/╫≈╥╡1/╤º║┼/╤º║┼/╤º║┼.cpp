#include<iostream>
using namespace std;
int main()
{
cout<<"�ֳ���ѧ�ź��λ:"<<endl;
cout<<"**********       **********"<<endl;
cout<<"*        *       *        *"<<endl;
cout<<"*        *       *        *"<<endl;
cout<<"*        *       **********"<<endl;
cout<<"*        *                *"<<endl;
cout<<"*        *                *"<<endl;
cout<<"*        *                *"<<endl;
cout<<"**********                *"<<endl;
return 0;
}
