#include <iostream>

using namespace std;

class J
{
public:
        J();
		J( int bl,int ll,int at,int sd,int gs,int ap,int mk,int hj,int hl,int hx);
		void zhuangtai();
		void jiaxue();
		void at();
		~J();
		int b1;
	    int b2;
        int b3;
        int b4;
        int b5;
        int b6;
        int b7;
        int b8;
        int b9;
        int b10;	
	

};