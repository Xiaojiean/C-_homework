#include<iostream>
#include"skills.h"
#include<string>
using namespace std;

inline void attack(int &attack_num)
{
	cout<<"��Ч���������"<<endl;
	cout<<attack_num++<<endl;
}

int main()
{
	string hero1, hero2,hero3,hero4,hero5;
	cout<<"�������Ӣ��:"<<endl;
	getline (cin, hero1);
	getline (cin, hero2);
	getline (cin, hero3);
	getline (cin, hero4);
	getline (cin, hero5);
	//sum = add(x,y);
	int orign_x, orign_y;
	cout<<"��˫������λ��:"<<endl;
	cin>>orign_x>>orign_y;
	int attack_number = 0;
	int skill1_num = 0;
	bool skill1_status = false;
	skill1_status = pokongzhan(orign_x, orign_y, skill1_num);
	skill1_num++;
	attack(attack_number);
	attack(attack_number);
	skill1_status = pokongzhan(orign_x, orign_y, skill1_num);
	skill1_num++;
	attack(attack_number);
	attack(attack_number);
	laoluntexinyandao();
	cout<<skill1_status<<endl;
	bool skill3_enable = false;
	qianjinpenquan(attack_number, skill3_enable);
	if(skill3_enable)
	{
		lirenhuaerzi();
		cout<<"��˫���� Penta kill!"<<endl;
		cout<<hero1<<","<<hero2<<","<<hero3<<","<<hero4<<","<<hero5<<"����һȺ�˼�";
	}
	else
	{
		cout<<"�һ��ܴ�ʮ����"<<endl;
	}
}