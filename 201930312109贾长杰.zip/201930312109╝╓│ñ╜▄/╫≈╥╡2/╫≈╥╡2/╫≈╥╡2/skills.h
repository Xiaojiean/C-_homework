#include<iostream>
using namespace std;
void qianjinpenquan(int attacks, bool &Skill3Enable);
bool pokongzhan(int &X, int &Y, int num);
void laoluntexinyandao();
void lirenhuaerzi();
