#include<iostream>
using namespace std;
void beidong(int attack_number);
void q();
void w();
void e(int x,int y);
void r();
