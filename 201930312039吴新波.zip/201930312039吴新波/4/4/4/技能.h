#include <iostream>
using namespace std; 
void skill(int shanghai );
