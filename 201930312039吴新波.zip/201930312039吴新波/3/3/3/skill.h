#include<iostream>
using namespace std;
void beidong(int attack_number);