#include<iostream>
using namespace std;
void B(int x);
void Y1(int x);
void Y2();
void Y3();
void Y4();
inline int attack(int x);