#include <iostream>
#include"skill.h"

inline int attack(int x)
{   cout<<"��ͨ����"<<endl;
	return x*130;
}
int main()
{
	int x;
	cin>>x;
	int m;
	m=attack(x);
	B(x);
	Y2();
	Y3();
	Y4();
    cout<<m<<endl;
	cout<<"һɱ	"<<endl;
	cout<<"��ɱ	"<<endl;
	cout<<"��ɱ	"<<endl;
	cout<<"��ɱ	"<<endl;
	cout<<"��ɱ	"<<endl;
}
