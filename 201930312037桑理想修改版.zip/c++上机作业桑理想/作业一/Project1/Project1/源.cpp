#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	cout<<"�ҵ�ѧ����:            "<<endl;
	cout<<"  *****   *******      "<<endl;
	cout<<"      *        *      "<<endl;
	cout<<"  *****       *       "<<endl;
	cout<<"      *       *       "<<endl;
	cout<<"  *****       *       "<<endl;
	getch();
	return 0;
}