#include<iostream>
using namespace std;

class daji
{
public:
	 daji();
	 daji(int a);
     void a1();
	 void b1(double x);
	 double d;
};