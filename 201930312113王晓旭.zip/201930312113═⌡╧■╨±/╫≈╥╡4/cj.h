#include <iostream>

using namespace std;

class cj
{
public:
        cj();
		cj( int xl,int x2,int x3);
		//cj(int y1,int y2,int y3);
		void showd();
		void zhuangtai();
		void shoulei();
		~cj();
		int d1;
	    int d2;
		int d3;
		int d4;
		int d5;
		int d6;
		int xz;
	
};
