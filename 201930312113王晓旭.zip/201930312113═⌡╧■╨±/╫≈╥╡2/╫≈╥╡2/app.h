#include <iostream> 

using namespace std; 

void tuichuyouxi();
void luodichenghe ();