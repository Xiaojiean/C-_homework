﻿#include<iostream>
using namespace std;
int main()
{
	int age;
	cout << "Please input your age:" << endl;
	cin >> age;
	cout << "Hello world!I am " << age << endl;
	cout << "这是石小可同学的第一个C++程序，特此纪念。" << endl;
	cout << "Copyright ©2021-2099 ShiXiaoke. All rights reserved." << endl;
	return 0;
}