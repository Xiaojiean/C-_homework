#include<iostream>
using namespace std;
class Complex {
public:
	double real;
	double imag;
	Complex(double r = 0, double i = 0)
	{
		real = r; imag = i;
	}
};
Complex operator*(Complex co1, Complex co2)
{
	Complex temp;
	temp.real = co1.real * co2.real - co1.imag * co2.imag;
	temp.imag = co1.imag * co2.real + co2.imag * co1.real;
	return temp;
}
int main()
{
	cout << "��ֱ���������������ʵ�����鲿��" << endl;
	double x[2], y[2];
	cin >> x[0] >> y[0] >> x[1] >> y[1];
	Complex com1(x[0], y[0]), com2(x[1], y[1]), total;
	total = com1 * com2;
	cout << "com1(1.1, 2.2) * com2(3.3, 4.4) = real��" << total.real << " " << "��+ imag��" << total.imag << "��" << endl;

	return 0;
}