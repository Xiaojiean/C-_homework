#include <iostream>
using namespace std;
class hero
{
public:
        hero();
		hero( int xl,int mf);
		void showd();
		void zhuangtai();
		void at();
		~hero();
		int d1;
	    int d2;
private:
	

};
