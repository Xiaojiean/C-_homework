#include <iostream>
#include "hero.h"
using namespace std; 


hero::hero( int xl,int ml)
{
	
   d1=xl;
   d2=ml ;
}
void hero ::showd()
{
cout<<"Ӣ��Ѫ��:";cout<<d1 <<endl;
cout<<"Ӣ��ħ��:";cout<< d2 <<endl;
}
void hero::zhuangtai()
{
	d1 =d1;
	d2 =d2;
}
void hero::at()
{
d1= d1-50;
d2= d2-20;
}
hero::~hero ()
{
	cout<<"����!"<<endl ;
};