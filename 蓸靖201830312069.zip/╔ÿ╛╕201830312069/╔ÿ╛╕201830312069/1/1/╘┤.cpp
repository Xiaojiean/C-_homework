#include <iostream> 
using namespace std;
int main()
{
	cout << "ɘ����ѧ�ź���λ�ǣ�" << endl;
	cout << "******     ****** " << endl;
	cout << "*          *    *" << endl;
	cout << "*          *    *" << endl;
	cout << "******     ****** " << endl;
	cout << "*    *          * " << endl;
	cout << "*    *          * " << endl;
	cout << "******     ******\n " << endl;

	return 0;

}
