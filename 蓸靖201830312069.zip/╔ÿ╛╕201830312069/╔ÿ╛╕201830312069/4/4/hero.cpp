#include <iostream>
#include "hero.h"
using namespace std;
Daji::Daji(int xl)
{
	d1 = xl;//Ѫ��
}
	void Daji::showd()
	{
		cout << "Ӣ��Ѫ��:"; cout << d1 << endl;
	}
	void Daji::jiaxue()
	{
		d1 = d1 + 10;
		d2 = d2 - 10;
	}
	void Daji::at()
	{
		d1 = d1 - 50;
	}
	Daji::~Daji()
	{
		cout << "����" << endl;
	};