#include<iostream>
#include"HERO.h"

using namespace std;
int main()
{
	HERO libai;
	HERO sunwukong = HERO(10, 10, 10);
	HERO hanxin = sunwukong;
	libai = sunwukong;
	return 0;
}


