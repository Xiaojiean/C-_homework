#include"skill.h"
void Chilianhuozhong()
{
	cout<<"Nezha Increase defense"<<endl;

}
void Huoyansanjianqiang()
{
	cout<<"Continuous damage"<<endl;

}
void Huntianling()
{
	cout<<"Range damage"<<endl;
}
  void Qiankuantianjiang()
{
    cout<<"Kill the enemy"<<endl;
}