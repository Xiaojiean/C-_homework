#include<iostream>
using namespace std;
void Chilianhuozhong();
void Huoyansanjianqiang();
void Huntianling();
void Qiankuantianjiang();