#include<iostream>
using namespace std;
int b1;int b2;int b3;
class skill1{
	public:
		skill1(int i)
		{
			b1=i;
			
		}
		void print()
		{
			cout<<"Blue strip two hundred"<<endl<<"Function one "<<endl<<"Restore life"<<b1<<"hp"<<endl;
		}
		~skill1()
		{
			cout<<"This is skill1 destructor"<<endl;}

		};
class skill2
{public:
		skill2(int i)
		{
			b1=i;
			
		}
		void print()
		{
			cout<<"Function two"<<endl<<"Increasing"<<b1<<"Shield"<<endl;
		}
		~skill2()
		{
			cout<<"This is skill2 destructor"<<endl;}
		
		};

class skill3 : public skill1 , public skill2{
	public:
		skill3(int i, int j,int l);
		void print();
	private:
		int a;
		
};
skill3 ::skill3(int i,int j,int l) :skill1(i),skill2(j)
{
	a=l;

}
void skill3::print()
{
	skill1::print();
	skill2::print();
	cout<<"Function three"<<endl<<"Cause it to enemy"<<a<<"Damage"<<endl;
}
int main()
{
 skill3 aa(200,200,100);
 aa.print();
 return 0;
}
