#include<iostream>
using namespace std;
int i,a,b,a1,b1;
void skill()
{
	i=2000;
	cout<<"Skill base injuries are "<<i<<endl;
}
void shield ()
{
	
	a1=b*(i/(a+b));
	b1=a*(i/(a+b));
	cout<<"Hero 1 take damages as"<<a1<<endl<<"Hero 2 take damages as"<<b1<<endl;

}
void main()
{
	cout<<"Enter shield values for hero 1 and hero 2��0��100��Χ�ڣ�";	
	cin>>a>>b;
	 skill();
	 shield ();
}

