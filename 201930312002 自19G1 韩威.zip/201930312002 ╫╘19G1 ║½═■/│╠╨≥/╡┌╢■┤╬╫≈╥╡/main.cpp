#include<iostream>
#include"skill.h"
using namespace std;
inline void attack()

{
  cout<<"Ordinary damage"<<endl;
}
int main(int i)
{
	
	for(i=1;i<6;i++)
	{
	attack();
	Chilianhuozhong();
	Huoyansanjianqiang();
	Huntianling();
	Qiankuantianjiang();
	cout<<"You killed the hero"<<i<<endl;
	if(i==5)
	{
		cout<<"��������!";
	}
	}
	return 0;
}
	