#include <iostream>

using namespace std;

class hero
{
	public:
		hero( int x,int y,int z,int h);
		void display();
		void skill1();
		void skill2();
		~hero();
		int a;
		int b;
	    int c;
		int d;
};