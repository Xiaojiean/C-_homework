#include"subhero.h"
#include<string>

Subhero::Subhero():Hero()
{
	skill4 = 0;
	ratio = 1;
}
Subhero::Subhero(int x1, int x2, int x3, int x4, string s, int hero_blood, 
				 float hero_orign_x,  float hero_orign_y, bool hero_movement, int hero_ratio)
				 :Hero(x1,x2, x3, s, hero_blood, hero_orign_x, hero_orign_y, hero_movement)
{
	skill4 = x4;
	ratio = hero_ratio;

}
Subhero::~Subhero()
{

}

void Subhero::use_skill4(int x)
{
	ratio = x;
}

int Subhero::use_skill1( bool hero_skill1_damage, bool hero_skill1_skip,
				int hero_skill1_times, int current, float length_x, 
				float length_y,  int stop_time, bool stop, Hero &target)
{
	if(hero_skill1_damage==false)
		return 200;
	else
	{
		skill1 = skill1 * ratio;
		target.blood = target.blood - skill1;
		if(target.blood < 0)
			cout << "Death!" << endl;
	}
	if(hero_skill1_skip==true)
	{
		if(current < hero_skill1_times)
		{
			orign_x = orign_x + length_x;
			orign_y = orign_y + length_y;			
		}
	}
	if(stop==true)
	{
		target.movement = false;
		int i = 0;
		while(i<stop)
			i++;
	}
	return skill1;
}
