 #include <iostream> 
//#include <conio.h> 
using namespace std; 
 int main()
 { cout<<"�����Ե�ѧ�ź���λ�ǣ�"<<endl;
	 cout<<"  ****     **********  "<<endl;
	 cout<<" *****     ***    ***  "<<endl;
     cout<<"  ****     ***    ***  "<<endl;
	 cout<<"  ****     ***    ***  "<<endl;
	 cout<<"  ****     ***    ***  "<<endl;
	 cout<<"  ****     ***    ***  "<<endl;
	 cout<<"  ****     ***    ***  "<<endl;
	 cout<<"  ****     ***    ***  "<<endl;
	 cout<<"  ****     ***    ***  "<<endl;
	 cout<<" ******    **********  \n "<<endl; 

	 return 0;
	 
 }
