#include<iostream>
#include <conio.h>
using namespace std;
int main()
{    
	int age; 
	cout<<"Please input your AGE:"<<endl; 
	cin>>age;
	cout<<"Hello, probie! I am "<<age<<endl;
	getch();
	return 0;
}

