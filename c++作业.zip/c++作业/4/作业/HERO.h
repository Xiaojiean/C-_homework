#include<iostream>
using namespace std;

class HERO
{
public:
	HERO();
	HERO(int xl, int ll, int fq, int wg, int wk ,int mk ,int sd );
	void lb();
	int x1,x2,x3,x4,x5,x6,x7;
	void xy();
	int xl,ll,fq,wg,wk,mk,sd;
};
