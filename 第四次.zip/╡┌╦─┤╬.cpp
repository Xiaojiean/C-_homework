#include <iostream>
using namespace std;
static float m_classMoney = 1000;
class TStudent
{
	char* name;
public:

	void InitStudent(char name[])
	{
		name = name;

	}
	void ExpendMoney(float money, char name[]);

	void showMoney();

};

void TStudent::ExpendMoney(float money, char name[])
{
	m_classMoney -= money;
	cout << name << "���Ѱ��" << money << "Ԫ" << endl;
}

void TStudent::showMoney()
{
	cout << "��ѻ�ʣ��" << m_classMoney << "\n" << endl;

}

int main()
{
	TStudent stu[3];
	char name[3][100];
	int i;
	double money[3] = { 50,98.5,500.53 };
	for (i = 0; i < 3; i++)
	{
		cout << "����������:";
		cin >> name[i];
		stu[i].InitStudent(name[i]);
		stu[i].ExpendMoney(money[i], name[i]);
		stu[i].showMoney();
	}

}