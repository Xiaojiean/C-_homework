#include<iostream>
#include"hero.h"
using namespace std;

int main()
{
    Hero Libai;
	cout<<"Libai skills:"<<endl;
	Libai.showskill();

	Hero Sunwukong = Hero(10,10,10);
	cout<<"Libai skills:"<<endl;
	Sunwukong.showskill();

	Hero Hanxin(Sunwukong);
	cout<<"Hanxin skills:"<<endl;
	Hanxin.showskill();

	Libai = Sunwukong;
	cout<<"Libai skills:"<<endl;
	Libai.showskill();

	return 0;
}


