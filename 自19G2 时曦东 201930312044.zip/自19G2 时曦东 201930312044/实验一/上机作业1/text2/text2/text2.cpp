#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	cout<<"ʱ�ض���ѧ�ź���λ��:"<<endl;
	cout<<" *   *        *   *      "<<endl;
	cout<<"*    *       *    *      "<<endl;
	cout<<"* ** *       * ** *      "<<endl;
	cout<<"     *            * "<<endl;
	cout<<"     *            * "<<endl;
	cout<<"     *            *"<<endl;
	getch();
	return 0;
}