
#include <iostream>
#include"hero.h"
using namespace std; 
int jishashu=0;

inline void putonggongji()
{
int a2;
cout<<"1.a"<<endl;
cin>>a2;

switch(a2) 
{ 
case 1 :jishashu =jishashu +1;break; 

default : cout<<"ѡ�����"<<endl;break; 

} 
}

int main()
{	
skill direnjie;
cout<<"���ʽ�"<<endl;
int gongji;
 cout<<"��ͨ������1"<<endl; 
 cout<<"����׷�װ�2"<<endl;
 cout<<"���Ѱ�3"<<endl;
 cout<<"�������4"<<endl;
 cin>>gongji; 

while(gongji!=5)
{
switch(gongji) 

{ 
	case 1 : putonggongji();break; 
}
switch(gongji) 
{
	case 2 : liulingzhuixiong();break; 
}
switch(gongji) 
{   
	case 3 : taotuo();break; 
}
switch(gongji) 
{   
	case 4 : wangchaomiling();break; 
}
jishu();
} 
}