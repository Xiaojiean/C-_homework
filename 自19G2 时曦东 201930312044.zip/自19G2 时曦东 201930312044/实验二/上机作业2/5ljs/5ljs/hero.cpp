
#include <iostream>
#include"hero.h"
using namespace std;
 void liulingzhuixiong()
 {
   int a3;
   cout<<"2.b"<<endl;
   cin>>a3;

   switch(a3) 
{ 
case 2 :jishashu =jishashu +1;break; 

default : cout<<"ѡ�����"<<endl;break; 

} 
}
 void taotuo()
{
   int a4;
   cout<<"������������Ѹ�ݵ���"<<endl;
   cin>>a4;
} 
  void wangchaomiling()
  {
     int a5;
   cout<<"4.d"<<endl;
   cin>>a5;
    switch(a5) 
{ 
case 4 :jishashu =jishashu +1;break; 

default : cout<<"ѡ�����"<<endl;break; 

} 
}
  
