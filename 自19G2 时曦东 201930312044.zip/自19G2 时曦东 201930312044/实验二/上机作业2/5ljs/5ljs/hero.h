#include <iostream>
using namespace std; 
 void jishu();
 void liulingzhuixiong();
 void taotuo();
  void wangchaomiling();
 inline void putonggongji();
 extern int jishashu;
class skill
{
public:
	skill()
	{
		skill1 = 1;
		skill2 = 2;
		skill3 = 3;
	}
	void showskill()
	{
		cout <<skill1 << endl;
		cout <<skill2 << endl;
		cout << skill3 << endl;
	}

	inline void putonggongji()
	{   
		cout << "1.��ͨ����" << endl;
	}

private:
	int skill1;
	int skill2;
	int skill3;
};


 