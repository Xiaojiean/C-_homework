#include<iostream>
//#include"hero.h"
#include"subhero.h"
using namespace std;

int main()
{

	Hero Sunwukong = Hero(0, 0, 200, "Sunwukong", 500, 0.0, 0.0, true);
	cout<< Hero::shownum() << endl;
	Hero Libai = Hero(50, 0, 400, "Libai", 500, 0.0, 0.0, true);
	cout<< Hero::shownum() << endl;
	Hero Luban = Hero(200, 200, 200, "Luban", 400, 0.0, 0.0, true);
	int tmp_blood;
	tmp_blood = Sunwukong.use_skill1(false, false, 1, 1, 0, 0, 0, false, Libai, Luban);
	Sunwukong.blood = Sunwukong.blood + tmp_blood;
	int current_Libai_skll1=0;
	cout << "Libai skill1 length_x and length_y:" << endl;
	float length_x, length_y;
	cin >> length_x >> length_y;
	Libai.use_skill1(true, true, 3, current_Libai_skll1++, 
		length_x, length_y, 20, true, Sunwukong, Luban);

	cout<< Sunwukong.blood<<endl;
	cout<< Sunwukong.movement<<endl;
	cout<< Hero::shownum() << endl;

	Subhero Ganjiangmoxie(200, 200, 200, 0, "Luban", 400, 0.0, 0.0, true, 1);
	Ganjiangmoxie.use_skill4(2);
	Ganjiangmoxie.use_skill1(true, false, 1, 1, 0, 0, 0, false, Luban);
	cout << Luban.blood << endl;

	return 0;
}

