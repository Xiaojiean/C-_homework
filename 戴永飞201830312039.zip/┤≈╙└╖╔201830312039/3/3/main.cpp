#include<iostream>
#include"hero.h"

using namespace std;
int main()
{
	Hero libai;
	Hero sunwukong = Hero(10, 10, 10);
	Hero hanxin = sunwukong;
	libai = sunwukong;
	return 0;
}


