#include <iostream>
#include"hero.h"
using namespace std;
void jishu()
{
	if (jishashu == 1) //1sha
	{
		cout << "frist bleed" << endl;

	}
	if (jishashu == 2) //2
	{
		cout << "double kill" << endl;

	}
	if (jishashu == 3) //3
	{
		cout << "tryballkill" << endl;

	}
	if (jishashu == 4) //4
	{
		cout << "wazhuakill" << endl;

	}
	if (jishashu >= 5) //5
	{
		cout << "pentalkill" << endl;
		return win();
	}
}