#include<iostream>
using namespace std;

class Hero
{
public:
	 Hero(int a);
	 ~Hero();
	 void V();
     void W(int x);
private:
	 int i;
};