#include<iostream>
#include<conio.h>
using namespace std;
int main()
{   
	int a;
	cin>>a;
	cout<<"���񱦵�ѧ�ź���λ��"<<endl;
	cout<<"    **       *****   "<<endl;
	cout<<"   * *       *       "<<endl;
	cout<<"  ******     *****   "<<endl;
	cout<<"     *           *   "<<endl;
	cout<<"     *       *****   "<<endl;
	getch();
	return 0;
}