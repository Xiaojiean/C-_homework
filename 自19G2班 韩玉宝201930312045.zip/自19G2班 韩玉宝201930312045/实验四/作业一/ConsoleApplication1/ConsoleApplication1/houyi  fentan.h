#include<iostream>
using namespace std;

class hero
{
public:
	 hero();
	 hero(int a,int b);
     void w();
	 void hero::u();
     void hero::v();
	 int d;
	 int e;
};
