#include<iostream>
using namespace std;
void C(int x);
void D(int x);
void L();
void Z();
inline int attack(int x);