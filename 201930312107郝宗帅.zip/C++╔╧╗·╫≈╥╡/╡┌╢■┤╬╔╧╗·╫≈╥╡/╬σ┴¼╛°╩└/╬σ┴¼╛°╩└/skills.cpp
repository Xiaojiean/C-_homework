#include"skills.h"
void YiQiDangQian(int attacks, bool&Skill3Enable)
{
}

bool DanDaoFuHui(int&X, int&Y, int num)
{
	return false;
}
void QingLongYanYue()
{
}
void DaoFengTieJi()
{
	int  DFTJ;
	cout<<"�޴��˺�"<<endl;
}

