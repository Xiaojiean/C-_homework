#include<iostream>
using namespace std;
void YiQiDangQian(int attacks, bool&Skill3Enable);
bool DanDaoFuHui(int &X, int &Y, int num);
void QingLongYanYue();
void DaoFengTieJi(int  DFTJ );