#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int ����˧ѧ��;
	cout<<"Please input ����˧ѧ��:"<<endl;
	cin>>����˧ѧ��;
	cout<<"********"<<"      "<<"********"<<endl;
	cout<<"*      *"<<"      "<<"     *  "<<endl;
	cout<<"*      *"<<"      "<<"    *   "<<endl;
	cout<<"********"<<"      "<<"   *    "<<endl;
	getch();
	return 0;
}


