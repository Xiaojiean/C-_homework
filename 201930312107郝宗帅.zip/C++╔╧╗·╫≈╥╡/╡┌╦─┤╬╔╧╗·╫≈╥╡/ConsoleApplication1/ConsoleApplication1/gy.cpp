#include <iostream>
#include "gy.h"
using namespace std;



gy::gy( int hp,int mp,int gj,int sd,int gs,int fq,int mk,int wk,int hmp,int hhp)//Ӣ������
{
	
   P1=hp;//HP
   P2=mp;//MP
   P3=gj;//����
   P4=sd;//�ٶ�
   P5=gs;//����
   P6=fq;//��ǿ
   P7=mk;//ħ��
   P8=wk;//�￹
   P9=hmp;//MP�ظ�
   P10=hhp;//HP�ظ�
}
void gy::showd()
{
cout<<"HP:";cout<<P1 <<endl;
cout<<"MP:";cout<< P2 <<endl;
cout<<"����:";cout<< P3<<endl;
cout<<"�ٶ�:";cout<< P4<<endl;
cout<<"����:";cout<< P5 <<endl;
cout<<"��ǿ:";cout<< P6<<endl;
cout<<"ħ��:";cout<< P7<<endl;
cout<<"�￹:";cout<< P8<<endl;
cout<<"�ָ�MP:";cout<< P9 <<endl;
cout<<"�ָ�HP:";cout<< P10 <<endl;
}
void gy::beidongjineng()
{
	P5 =P5 +10;
	P8 =P8 +10;
	P2 =P2 -10;
}
void gy::at()
{
P1= P1-50;
}
void gy::lunhui1 ()
{
P2=P2-100;
}
void gy::lunhui2 ()
{
P1=P1-200;
}

void gy::fangyu  ()
{
P7=P7*2;
P8=P8*2;
}





