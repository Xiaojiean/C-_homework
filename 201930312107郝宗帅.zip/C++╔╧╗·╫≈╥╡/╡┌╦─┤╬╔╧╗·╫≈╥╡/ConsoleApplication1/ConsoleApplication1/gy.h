#include <iostream>
using namespace std;
class gy 
{
public:
        gy();
		gy( int hp,int mp,int gj,int sd,int gs,int fq,int mk,int wk,int hmp,int hhp);
		void showd();
		void beidongjineng();
		void at();
		void lunhui1();
		void lunhui2();
		void fangyu();
		int P1;
	    int P2;
        int P3;
        int P4;
        int P5;
        int P6;
        int P7;
        int P8;
        int P9;
        int P10;	
};
void solo();