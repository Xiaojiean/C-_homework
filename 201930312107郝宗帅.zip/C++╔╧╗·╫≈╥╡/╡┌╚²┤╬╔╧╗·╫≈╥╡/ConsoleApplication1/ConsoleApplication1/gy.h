#include<iostream>
using namespace std;
class gy
{
public:
	gy();
	gy(int xl,int mf,int gj,int sd,int gs,int fq,int mk,int wk,int hl,int hx);
	void showd();
	void jineng();
	void at();
	~gy();
	int d1;
	int d2;
	int d3;
	int d4;
	int d5;
	int d6;
	int d7;
	int d8;
	int d9;
	int d10;
private:
};