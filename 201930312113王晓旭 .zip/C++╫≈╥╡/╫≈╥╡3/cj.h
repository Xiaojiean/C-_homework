#include <iostream>

using namespace std;

class cj
{
public:
        cj();
		cj( int xl,int x2);
		void showd();
		void zhuangtai();
		~cj();
		int d1;
	    int d2;
	
};
