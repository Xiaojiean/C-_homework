#include<iostream>
using namespace std;

class juzi
{
public:
	 juzi(int a);
	 ~juzi();
	 int get_i();
     void W(double x);
private:
	int i;
};
