#include <iostream>
using namespace std;
int max(int a[5])
{
	int i, m = a[0], x;
	for (i = 1; i < 5; i++)
	{
		if (m < a[i])
		{
			x = m;
			m = a[i];
			a[i] = x;
		}
	}
	return m;
}