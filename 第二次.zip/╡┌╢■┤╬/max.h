
int max(int a[5]);