
int min(int a[5]);