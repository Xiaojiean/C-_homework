
#include <iostream>
using namespace std;
class sx
{
public:
        sx();
		sx( int xl,int mf);
		void showd();
		void showd1();
		void showd2();
		void jiaxue();
		void at();
		void bt();
		~sx();			
        int d1;
	    int d2;    
};
