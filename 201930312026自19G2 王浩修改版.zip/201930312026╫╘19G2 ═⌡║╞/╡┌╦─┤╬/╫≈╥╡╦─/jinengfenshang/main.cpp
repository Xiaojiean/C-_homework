#include <iostream>
#include "shuxing.h"
using namespace std; 
int main()
{
 int i;
 cout<<"1.��Ѫ  ";
 cout<<"2.����  ";
 cout<<"3.����  ";
 cout<<"4.�˳�  "<<endl;
 cin>>i; 
 sx luban(100,100);
 sx dianwei(100,100);
 sx zhongkui(100,100);
 while(i!=4)
 {	
  switch (i)
  {
	case 1: {
		    dianwei .jiaxue ();dianwei.showd ();
			if (dianwei.d2 ==0)
			{cout <<"��������"<<endl;
			}
			}
	      break ;
	case 2: luban.at(); luban .showd1 ();
		 if (luban .d1==0)
          {cout<<"³������"<<endl ;
		 } 
	      zhongkui.bt(); zhongkui .showd2();
		 if (zhongkui .d1==0)
          {cout<<"��ظ����"<<endl ;
		 zhongkui.~sx ();
		 }break ;
	case 3:  dianwei.showd ();
             luban .showd1 ();
             zhongkui .showd2 ();break ;
	 default :cout<<"error"<<endl;break;
   }
 cin>>i;
 }
return  0;
}