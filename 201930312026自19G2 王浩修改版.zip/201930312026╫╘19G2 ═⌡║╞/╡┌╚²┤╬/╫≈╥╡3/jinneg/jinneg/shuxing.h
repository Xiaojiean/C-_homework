#include <iostream>
using namespace std;
class sx
{
public:
        sx();
		sx( int xl,int mf);
		void showd();
		void jiaxue();
		void at();
		~sx();			
        int d1;
	    int d2;    
};
