#include <iostream>
#include "shuxing.h"
using namespace std; 
sx::sx( int xl,int mf)
{
   d1=xl;
   d2=mf ;  
}
void sx ::showd()
{
cout<<"Ӣ��Ѫ��:";cout<<d1 <<endl;
cout<<"Ӣ������:";cout<< d2 <<endl;
}
void sx::jiaxue()
{
	d1 =d1+10;
	d2 =d2-10;
}
void sx::at()
{
d1= d1-50;
}
sx::~sx ()
{
cout<<"virctory"<<endl ;
};