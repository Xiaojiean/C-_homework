#include <iostream>
#include "shuxing.h"
using namespace std; 
int main()
{
 int i;
 cout<<"1.��Ѫ  ";
 cout<<"2.����  ";
 cout<<"3.����  ";
 cout<<"4.�˳�  "<<endl;
 cin>>i; 
 sx luban(100,100);
 sx yingxiong(100,100);
 while(i!=4)
 {	
	
  switch (i)
  {
	case 1: {
		    yingxiong .jiaxue ();yingxiong.showd ();
			if (yingxiong.d2 ==0)
			{cout <<"��������"<<endl;
			}
			}
	      break ;
	case 2: luban.at(); luban .showd ();
		 if (luban .d1==0)
          {cout<<"��������"<<endl ;
		 luban.~sx ();}break ;
	case 3: yingxiong.showd ();break;
	 default :cout<<"error"<<endl;break;
   }
 cin>>i;
 }
return  0;
}