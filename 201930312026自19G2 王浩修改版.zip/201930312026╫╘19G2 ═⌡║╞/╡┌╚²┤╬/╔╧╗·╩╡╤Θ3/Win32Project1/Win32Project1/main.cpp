#include<iostream>
#include"hero.h"
using namespace std;
int main()
{
Hero libai;
cout<< "libai skills:"<<endl;
libai.showskill();

Hero sunwukong = Hero(10, 10, 10);
cout<< "sunwukong skills:"<<endl;
sunwukong.showskill();

Hero hanxin(sunwukong);
cout<< "hanxin skills:"<<endl;
hanxin.showskill();
libai = sunwukong;
cout<< "libai skills:"<<endl;
libai.showskill();
return 0;
}