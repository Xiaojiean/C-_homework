#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    cout<<"*********    ************"<<endl;
    cout<<"*********    ************"<<endl;
	cout<<"      ***    ****        "<<endl;
	cout<<"      ***    ****        "<<endl;
	cout<<"*********    ************"<<endl;
	cout<<"*********    ************"<<endl;
    cout<<"***          ****    ****"<<endl;
    cout<<"***          ****    ****"<<endl;
    cout<<"*********    ****    ****"<<endl;
    cout<<"*********    ************"<<endl;
    

getch();
return 0;

}