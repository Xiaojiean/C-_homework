#include<iostream>
using namespace std;
int main()
{
int age;
cout<<"Please input you AGE"<<endl;
 cin>>age;
cout<<"hello,world! i am"<<age<<endl;
 return 0;
}