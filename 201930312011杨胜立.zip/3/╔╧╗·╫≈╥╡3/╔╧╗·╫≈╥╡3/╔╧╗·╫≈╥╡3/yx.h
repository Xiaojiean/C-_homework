#include <iostream>

using namespace std;

class yx
{
public:
        yx();
		yx( int xl,int mf,int gj,int sd,int gs,int fq,int mk,int wk,int hl,int hx);
		void showd();
		void jiaxue();
		void at();
		~yx();
		int d1;
	    int d2;
        int d3;
        int d4;
        int d5;
        int d6;
        int d7;
        int d8;
        int d9;
        int d10;	
private:
	

};


