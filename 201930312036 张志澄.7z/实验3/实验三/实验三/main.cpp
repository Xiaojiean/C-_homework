#include <iostream>
#include"hero.h"
int A(int x);

int main()
{   
   int b;
   cout<<"��ɪ׼���ͷż���"<<endl;
   cin>>b;
   hero y(1000);
        y.get_i();
        y.A(1);
}
  