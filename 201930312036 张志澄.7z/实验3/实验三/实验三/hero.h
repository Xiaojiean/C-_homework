#include<iostream>
using namespace std;

class hero
{
public:
	 hero(int a);
	 ~hero();
	 int get_i();
     void A(double x);
private:
	int i;
};