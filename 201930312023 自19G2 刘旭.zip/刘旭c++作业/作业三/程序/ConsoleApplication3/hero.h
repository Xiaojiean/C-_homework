#include<iostream>
using namespace std;

class Hero
{
public:
	Hero(int x);
	~Hero();
	int get_i();
	void  Hero::jifa(int a);
	void jifei();
	void shanghai();
	void huiti();
	void fuhuo();
private:
	int a;//���ܺ�
	int i;//Ѫ��
};

