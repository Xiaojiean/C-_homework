#include<iostream>
using namespace std;

class hero
{
public:
	 hero();
	 hero(int a,int b);
     int w(int x);
	 void hero::u(int shz);
     void hero::v();
	 int d;
	 int e;
};
