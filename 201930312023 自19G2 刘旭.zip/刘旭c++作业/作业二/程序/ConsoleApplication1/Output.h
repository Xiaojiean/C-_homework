#ifndef OUTPUT_H_INCLUDED
#define OUTPUT_H_INCLUDED


void Output();

#endif // OUTPUT_H_INCLUDED