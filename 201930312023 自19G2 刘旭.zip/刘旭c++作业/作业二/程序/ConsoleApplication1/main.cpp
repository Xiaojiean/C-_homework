#include <iostream>
#include"Output.h"
using namespace std;

int main()
{Output();
	
	cout << "����" << endl;
	int x;
	cin>>x;
	
	
}