#include<iostream>
using namespace  std;

int main()
{
	cout << "My student id:" << endl;
	cout << "" << endl;
	cout <<"       *        * "<< endl;
	cout <<"    *  *        * " << endl;
	cout <<"  *    *        * " << endl;
	cout <<" * *  ** * *    * " << endl;
	cout <<"       *        * " << endl;
	cout <<"       *        * "<< endl;

	return 0;

}