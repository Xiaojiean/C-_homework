#include"hero.h"
class Subhero :public Hero
{
public:
	Subhero();
	Subhero(int x1, int x2, int x3, int x4, string s, int hero_blood,
		float hero_orign_x, float hero_orign_y, bool hero_movement, int hero_ratio);
	~Subhero();
	int use_skill1(bool hero_skill1_damage, bool hero_skill1_skip,
		int hero_skill1_times, int current, float length_x,
		float length_y, int stop_time, bool stop, Hero &target);
	void use_skill4(int x);
private:
	int skill4;
	int ratio;
};
