#include<iostream>
using namespace std;
int main()
{
	printf(" *   *   *****\n"
		   " *   *   *   *\n"
		   " *****   *****\n"
		   "     *       *\n"
		   "     *   *****\n");
	getchar();
			   return 0;
}