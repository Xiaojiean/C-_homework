#include<iostream>
using namespace std;
int b1;int b2;int b3;
class skill1{
	public:
		skill1(int i)
		{
			b1=i;
			
		}
		void print()
		{
			cout<<"Lay out a visual field device"<<endl<<"Get a full view of the 600 to 1000 range "<<endl;
		}
		~skill1()
		{
			cout<<"this is a skill1 destructor"<<endl;}
		

		};
class skill2{
	public:
		skill2(int i)
		{
			b1=i;
			
		}
		void print()
		{
			cout<<"Snipe on hit targets and complete one damage"<<b1<<"Reduced movement speed by 90%"<<endl;
		}
		~skill2()
		{
			cout<<"this is a skill2 destructor"<<endl;}
		

		};



class skill3 : public skill1 , public skill2{
	public:
		skill3(int i, int j,int l);
		void print();
	private:
		int a;
		
};
skill3 ::skill3(int i,int j,int l) :skill1(i),skill2(j)
{
	a=l;


}
void skill3::print()
{
	skill1::print();
	skill2::print();
	cout<<"Do harm to the enenmy"<<a<<"damage"<<endl;
		

}
int main()
{
 skill3 aa(200,800,400);
 aa.print();
 return 0;
}