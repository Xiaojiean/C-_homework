#include<iostream>

using namespace std;
int i,a,b,a1,b1;


void skill()
{

	cout<<"Bailishouyue ability output damage "<<i<<endl;
}
	void blood ()
	{

	a1=b*(i/(a+b));
	b1=a*(i/(a+b));
	cout<<"The damage taken by the first hero  "<<a1<<endl<<"The damage taken by the second hero  "<<b1<<endl;

}
void skill1()
{
	
	cout<<"injury received"<<i<<endl;
}
int main()
{
	cout<<"Damage"<<endl;
	cin>>i;
	cout<<"Enter blood values for hero 1 and hero 2"<<endl;	
	cin>>a>>b;
	 skill();
	 blood ();
	 return 0;
}


