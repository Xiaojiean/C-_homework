#include<iostream>
using namespace std;
void Miaozhun();
void Kuangfengzhixi(int &X, int &Y, int num);
void Jingmizhiyan();
void Taotuo();