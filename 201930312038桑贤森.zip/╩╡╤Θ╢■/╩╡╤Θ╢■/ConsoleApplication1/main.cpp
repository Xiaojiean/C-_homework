#include<iostream>
#include"skills.h"
#include<string>
using namespace std;
inline void attack(int&attack_num)
{
	cout<<"Putonggongji"<<endl;
}
int main()
{
	string hero1,hero2,hero3,hero4,hero5;
	cout<<"Enter five targets to attack:"<<endl;
	getline(cin,hero1);
	getline(cin,hero2);
	getline(cin,hero3);
	getline(cin,hero4);
	getline(cin,hero5);
	cout<<"Output skills:"<<endl;
	string Putonggongji;
		getline(cin,Putonggongji);
	cout<<"Do great damage to the enemy"<<endl;
		cout<<"Balishouyue successful five kill"<<endl;
		cout<<hero1<<","<<hero2<<","<<hero3<<","<<hero4<<","<<hero5<<"All the enemy were killed"<<endl;
    	
		
}
