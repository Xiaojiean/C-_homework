
#include"skills.h"
void  Miaozhun()
{   
	int MZ;
	cout<<"Bailishouyue nomal attack deals 180% physical damage"<<endl;
}

void Jingmizhiyan( )
{  
	int JMZY;
	cout<<"Get a field of view device"<<endl;
}
void Kuangfengzhixi()
{  
	int KFZX;
	cout<<"Cause damage and slow down"<<endl;
 }
void Taotuo()
{
	int TT ;
	cout<<"Kill the enemy and flee"<<endl;
}