

#include <iostream>

using namespace std;

class hero
{
public:
       hero();
		hero( int a,int b);
		void showd();
		void jiaxue();
		void at();
		~hero();
		int x;
	    int y;
private:
	

};