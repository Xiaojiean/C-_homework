
#include <iostream>

using namespace std;

class hero
{
public:
       hero();
		hero( int xl,int mf);
		void showd();
		void jiaxue();
		void q();
		void w();
		~hero();
		int x;
	    int y;
private:
	

};