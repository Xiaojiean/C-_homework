#include <iostream>
#include "hero.h"
using namespace std; 


hero::hero( int a,int b)
{
	
   x=a;
   y=b;
}
void hero ::showd()
{
cout<<"Ӣ��Ѫ��:";cout<<x<<endl;
cout<<"Ӣ������:";cout<< y <<endl;
}
void hero::jiaxue()
{
	x =x+10;
	y =y-10;
}
void hero::q()
{
x= x-99;
}
void hero::w()
{
x= x-20;
}
hero::~hero ()
{
cout<<"����"<<endl ;
};
