#include<iostream>
using namespace std;

class hero
{
public:
	 hero(int a);
     void a1();
	 void a2(double x);
	 double h;
	 int d;
};