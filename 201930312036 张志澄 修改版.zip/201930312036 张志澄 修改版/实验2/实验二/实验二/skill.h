#include<iostream>
using namespace std;
class SKILL
{
public:
	SKILL()
	{};

void skill();
inline void attack();
};