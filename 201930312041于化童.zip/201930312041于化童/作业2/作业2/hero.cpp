
#include <iostream>
#include"hero.h"
using namespace std;
 void hushenzhoufa()
 {
   int skill1;
   cin>>skill1;

   switch(skill1) 
{ 
case 1 :jishashu =jishashu +1;break;
case 2 :jishashu =jishashu +1;break; 
case 3 :jishashu =jishashu +1;break;
case 4 :jishashu =jishashu +1;break; 

default : cout<<"ѡ�����"<<endl;break; 

} 
}
 void douzhanchongfeng ()
{
   int skill2;
   cin>>skill2;
   
   switch(skill2)
   { 
case 1 :jishashu =jishashu +1;break;
case 2 :jishashu =jishashu +1;break; 
case 3 :jishashu =jishashu +1;break;
case 4 :jishashu =jishashu +1;break; 

default : cout<<"ѡ�����"<<endl;break; 

} 
 }
  void ruyijingu ()
  {
     int skill3;
   cin>>skill3;
    switch(skill3) 
{ 
case 1 :jishashu =jishashu +1;break;
case 2 :jishashu =jishashu +1;break; 
case 3 :jishashu =jishashu +1;break;
case 4 :jishashu =jishashu +1;break; 

default : cout<<"ѡ�����"<<endl;break; 

} 
}
  
