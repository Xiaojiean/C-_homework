#include <iostream>

using namespace std;
void ruyijingu();
class hero
{
public:
        hero();
		hero( int xl,int mf);
		void showd();
		void jiaxue();
		void at();
		~hero();
		int d1;
	    int d2;
private:
	

};
