#include"iostream"
#include"add.h"
using namespace std;
int add(int a,int b);
int main()
{
	int x,y,sum;
	cout<<"Enter two number:"<<endl;
	cin>>x>>y;
	sum=add(x,y);
	cout<<x<<"+"<<y<<"="<<sum<<endl;
	return 0;
}
