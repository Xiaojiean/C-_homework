#include<iostream>
using namespace std;

class Hero
{
public:
	Hero();
	Hero(int x1, int x2, int x3, string s, int hero_blood, 
		float hero_orign_x,  float hero_orign_y, bool hero_movement);
	~Hero();
	void showskill();
	void changename(string myname);
	int use_skill1( bool hero_skill1_damage, bool hero_skill1_skip,
				int hero_skill1_times, int current, 
			   float length_x, float length_y,  int stop_time, bool stop, Hero &target, Hero &target1);
	int blood;
	bool movement;
	static int shownum();
protected:
	int skill1;
	int skill2;
	int skill3;
	int orign_x;
	int orign_y;
	string hero_name;
	static int hero_num;
};

