#include"hero.h"
#include<string>

int Hero::hero_num = 0;
int Hero::shownum()
{
	return hero_num;
}

Hero::Hero()
{
	cout << "This is a default constructor!" << endl;
	skill1 = 0;
	skill2 = 0;
	skill3 = 0;
	hero_name = "No_name";
	/*skill1_damage = false;
	skill1_skip = false;
	skill1_times = 0;
	skill1_wait_time = 0;*/
	orign_x = 0.0;
	orign_y = 0.0;
	blood = 1000;
	movement = true;
	/*
	skill1_stop = false;
	stop_time = 0.0;
	angle = 0.0;*/

}
Hero::Hero(int x1, int x2, int x3, string s, int hero_blood, float hero_orign_x, float hero_orign_y, bool hero_movement)
{
	cout << "This is a overloaded constructor!" << endl;
	skill1 = x1;
	skill2 = x2;
	skill3 = x3;
	hero_name = s;
	blood = hero_blood;
	orign_x = hero_orign_x;
	orign_y = hero_orign_y;
	movement = hero_movement;
	hero_num++;
}

int Hero::use_skill1( bool hero_skill1_damage, bool hero_skill1_skip, 
					 int hero_skill1_times, int current, float length_x, 
					 float length_y, int stop_time, bool stop, Hero &target, Hero &target1)
{
	if(hero_skill1_damage==false)
		return 200;
	else
	{
		target.blood = target.blood - skill1 / 2;
		target1.blood = target1.blood - skill1 / 2;
		if(target.blood < 0)
			cout << "Death!" << endl;
		if(target1.blood < 0)
			cout << "Double kill!" << endl;
	}
	if(hero_skill1_skip==true)
	{
		if(current < hero_skill1_times)
		{
			orign_x = orign_x + length_x;
			orign_y = orign_y + length_y;			
		}
	}
	if(stop==true)
	{
		target.movement = false;
		int i = 0;
		while(i<stop)
			i++;
	}
	return skill1;

}

Hero::~Hero()
{
	cout << "This is " << hero_name << "\'s destructor!" << endl;
}


void Hero::showskill()
{
	cout << skill1 << endl;
	cout << skill2 << endl;
	cout << skill3 << endl;
}

void Hero::changename(string myname)
{
	hero_name = myname;
}
