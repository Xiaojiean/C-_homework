#include<iostream>
using namespace std;
int main()
{
	cout<<"�ڻ�ͯ��ѧ�ź���λ�ǣ�"<<endl;
	cout<< "*     *       *"<<endl;
	cout<< "*     *       *"<<endl;
	cout<< "* * * * *     *"<<endl;
	cout<< "      *       *"<<endl;
	cout<< "      *       *"<<endl;
	
}
