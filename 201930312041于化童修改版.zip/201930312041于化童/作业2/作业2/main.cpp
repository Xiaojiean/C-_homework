
#include <iostream>
#include"hero.h"
using namespace std; 
int jishashu=0;

inline void dashengshenwei()
{
int beidong1;
cin>>beidong1;
switch(beidong1) 
{ 
case 1 :jishashu =jishashu +1;break;
case 2 :jishashu =jishashu +1;break; 
case 3 :jishashu =jishashu +1;break;
case 4 :jishashu =jishashu +1;break; 

default : cout<<"ѡ�����"<<endl;break; 

} 
}

int main()
{	
cout<<"�����"<<endl;
int gongji;
 cout<<"��ʥ������1"<<endl; 
 cout<<"�����䷨��2"<<endl;
 cout<<"��ս��水3"<<endl;
 cout<<"����𹿰�4"<<endl;
 cin>>gongji; 

while(gongji!=5)
{
switch(gongji) 

{ 
	case 1 :dashengshenwei();break; 
}
switch(gongji) 
{
	case 2 : hushenzhoufa();break; 
}
switch(gongji) 
{   
	case 3 : douzhanchongfeng();break; 
}
switch(gongji) 
{   
	case 4 : ruyijingu();break; 
}
jishu();
} 
}