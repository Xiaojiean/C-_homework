#include <iostream>
using namespace std; 
 void jishu();
 void hushenzhoufa();
 void douzhanchongfeng();
  void ruyijingu();
 inline void dashengshenwei();
 extern int jishashu;
