#include <iostream>
using namespace std;
class Hero
{
public:
	Hero();
	Hero(int bl, int ll, int at, int sd, int gs, int ap);
	void zhuangtai();
	void heianjingu1();
	void heianjingu2();
	void at();
	void fangyu();
	int b1;
	int b2;
	int b3;
	int b4;
	int b5;
	int b6;
private:
};
