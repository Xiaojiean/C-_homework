#include <iostream> 
using namespace std;
int main()
{
	cout << "�����ɵ�ѧ�ź���λ�ǣ�" << endl;
	cout << "******     ****** " << endl;
	cout << "     *     *    *" << endl;
	cout << "     *     *    *" << endl;
	cout << "******     ****** " << endl;
	cout << "     *          * " << endl;
	cout << "     *          * " << endl;
	cout << "******     ******\n " << endl;

	return 0;

}
