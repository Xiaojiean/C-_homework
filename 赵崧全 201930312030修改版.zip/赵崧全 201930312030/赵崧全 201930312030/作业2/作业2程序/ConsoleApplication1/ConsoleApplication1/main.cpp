#include <iostream> 
#include"app.h"
using namespace std;
int jisha;
inline void gongji ()
{
	jisha=jisha+1;
}
 int main()
 {
 cout<<"welcome to �ٻ�ʦϿ��"<<endl;
 cout<<"��Ϸ��ʼ��Ӣ��äɮ\n1ɱ��2�˳�������������"<<endl;
 int LOL; 
 cin>>LOL; 
while(LOL!=2)
{	
	if (LOL==1){gongji();}
	if (jisha==1){cout<<"******First Blood******"<<endl;}
	if (jisha==2){cout<<"******Double Kill******"<<endl;}
	if (jisha==3){cout<<"******Trible Kill******"<<endl;}
	if (jisha==4){cout<<"******Quadra Kill******"<<endl;}
	if (jisha==5){cout<<"******Penta  Kill******"<<endl;}
cin>>LOL ;
} 
return 0;
}