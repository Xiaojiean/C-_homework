#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	cout<<"This is my student number:"<<endl;
	cout<<"******   ******"<<endl;
	cout<<"     *   *    *"<<endl;
	cout<<"******   *    *"<<endl;
	cout<<"     *   *    *"<<endl;
	cout<<"******   ******"<<endl;
	getch();
	return 0;
}