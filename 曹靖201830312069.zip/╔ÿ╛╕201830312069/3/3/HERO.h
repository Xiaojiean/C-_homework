#include<iostream>
using namespace std;

class HERO
{
public:
	HERO();
	HERO(int x1, int x2, int x3);
	HERO(const HERO & name);
	~HERO();
	HERO &operator=(const HERO &rhs);
	void showskill();
private:
	int skill1;
	int skill2;
	int skill3;
};


