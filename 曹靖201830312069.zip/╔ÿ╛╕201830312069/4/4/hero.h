#include <iostream>
using namespace std;
class Daji
{
public:
	Daji();
	Daji(int xl);
	void showd();
	void jiaxue();
	void at();
	~Daji();
	int d1;
	int d2;
private:
};