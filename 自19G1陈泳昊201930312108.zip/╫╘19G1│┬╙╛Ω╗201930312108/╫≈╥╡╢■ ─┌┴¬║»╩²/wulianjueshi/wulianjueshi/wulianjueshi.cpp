#include"wulianjueshi.h"
void aaaaa(int attacks, bool&Skill3Enable)
{
}

bool bbbbb(int&X, int&Y, int num)
{
	return false;
}
void ccccc()
{
}
void ddddd()
{
	int  DFTJ;
	cout<<"�޴��˺�"<<endl;
}

