#include<iostream>
using namespace std;
void aaaaa(int attacks, bool&Skill3Enable);
bool bbbbb(int &X, int &Y, int num);
void ccccc();
void ddddd(int  DFTJ );