#include<iostream>
using namespace std;
int x1;int x2;int x3;
class xigou1{
	public:
		xigou1(int i)
		{
			x1=i;
			
		}
		void print()
		{
			cout<<"��������"<<endl;
		}
		~xigou1()
		{
			cout<<"��������1"<<endl;}
		

		};
class xigou2{
	public:
		xigou2(int i)
		{
			x1=i;
			
		}
		void print()
		{
			cout<<"����"<<x1<<"Ѫ��"<<endl;
		}
		~xigou2()
		{
			cout<<"��������2"<<endl;}
		

		};



class xigou3 : public xigou1 , public xigou2{
	public:
		xigou3(int i, int j,int l);
		void print();
	private:
		int a;
		
};
xigou3 ::xigou3(int i,int j,int l) :xigou1(i),xigou2(j)
{
	a=l;


}
void xigou3::print()
{
	xigou1::print();
	xigou2::print();
	cout<<"�Ե������"<<a<<"�˺�"<<endl;
		

}
int main()
{
 xigou3 aa(200,200,100);
 aa.print();
 return 0;
}
