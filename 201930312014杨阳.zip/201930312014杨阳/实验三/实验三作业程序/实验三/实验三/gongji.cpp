#include <iostream>
#include "gongji.h"
using namespace std; 
shuxing::shuxing( int c1,int c2,int c3,int c4,int c5)
{
   b1=c1;
   b2=c2;
   b3=c3;
   b4=c4;
   b5=c5;
 }

